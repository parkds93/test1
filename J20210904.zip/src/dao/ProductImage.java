package dao;

public class ProductImage {
	private String pd_code;
	private String img_code;
	private String img_path;
	public String getPd_code() {
		return pd_code;
	}
	public void setPd_code(String pd_code) {
		this.pd_code = pd_code;
	}
	public String getImg_code() {
		return img_code;
	}
	public void setImg_code(String img_code) {
		this.img_code = img_code;
	}
	public String getImg_path() {
		return img_path;
	}
	public void setImg_path(String img_path) {
		this.img_path = img_path;
	}
}
